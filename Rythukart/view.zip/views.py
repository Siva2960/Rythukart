from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'index.html')

import pymysql
from django.views.decorators.csrf import csrf_exempt

# views.py
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
def checkUser(number):
    try:
        con = pymysql.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='123456',
            database='RK',
            charset='utf8'
        )
        with con.cursor() as cur:
            cur.execute("SELECT number FROM rythukart_register WHERE number=%s", (number,))
            result = cur.fetchone()
            return result is not None
    except Exception as e:
        print("Check user error:", e)
        return False
    finally:
        con.close()

def Register(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        number = request.POST.get('number')
        password = request.POST.get('password')

        # Validate inputs
        if not all([name, number, password]):
            return render(request, 'index.html', {'data': 'All fields are required'})

        # Check if user already exists
        if checkUser(number):
            return render(request, 'index.html', {'data': 'Phone number already registered'})

        # Insert new user
        try:
            db_connection = pymysql.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='123456',
                database='RK',
                charset='utf8'
            )
            with db_connection.cursor() as cursor:
                query = "INSERT INTO rythukart_register (name, number, password) VALUES (%s, %s, %s)"
                cursor.execute(query, (name, number, password))
                db_connection.commit()

                if cursor.rowcount == 1:
                    return render(request, 'R_S.html', {'data': 'Signup successful'})
                else:
                    return render(request, 'index.html', {'data': 'Signup failed, try again'})

        except Exception as e:
            print("Database insert error:", e)
            return render(request, 'index.html', {'data': 'Database error during signup'})

        finally:
            db_connection.close()

    return render(request, 'index.html', {'data': 'Invalid request method'})

def Login(request):
    if request.method == 'POST':
        number = request.POST.get('number')
        password = request.POST.get('password')

        con = pymysql.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='123456',
            database='RK',
            charset='utf8'
        )

        try:
            with con.cursor() as cur:
                sql = "SELECT name FROM rythukart_register WHERE number=%s AND password=%s"
                cur.execute(sql, (number, password))
                result = cur.fetchone()

                if result:
                    name = result[0]  # Get the name from result tuple
                    request.session['number'] = number  # Store number for session-based login

                    return render(request, 'home.html', {
                        'data': f'Welcome {name}',
                        'name': name,
                    })
                else:
                    return render(request, 'login.html', {'data': 'Invalid login details'})

        finally:
            con.close()

    return render(request, 'login.html')

def home(request):
    return render(request,'home.html')

def veg(request):
    products = Product.objects.filter(product_type='veg', stock__gt=0)
    return render(request, 'veg.html', {'products': products})

# views.py
from django.shortcuts import redirect, get_object_or_404
from .models import Product  # or Vegetable, if you have separate models

from decimal import Decimal  # to handle prices

def add_to_cart(request, product_id):
    cart = request.session.get('cart', {})
    product = get_object_or_404(Product, pk=product_id)

    product_id_str = str(product_id)
    if product_id_str in cart:
        cart[product_id_str]['quantity'] += 1
    else:
        cart[product_id_str] = {
            'quantity': 1,
            'price': str(product.price),  # convert Decimal to string to be JSON serializable
            'name': product.name
        }

    request.session['cart'] = cart
    return redirect('veg')  # adjust to your view name


def decrease_cart(request, product_id):
    cart = request.session.get('cart', {})
    product_id_str = str(product_id)

    if product_id_str in cart:
        if cart[product_id_str]['quantity'] > 1:
            cart[product_id_str]['quantity'] -= 1
        else:
            del cart[product_id_str]

    request.session['cart'] = cart
    return redirect('veg')




def pappu(request):
    products = Product.objects.filter(product_type='pappu')
    return render(request, 'pappu.html', {'products': products})

def rice(request):
    products = Product.objects.filter(product_type='rice')
    return render(request, 'rice.html', {'products': products})


from django.shortcuts import render, redirect
from .forms import ProductForm
from .models import Product

def admin_upload(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('admin_upload')
    else:
        form = ProductForm()
    return render(request, 'admin_upload.html', {'form': form})


def checkout(request):
    cart = request.session.get('cart', {})  # Example: { 'product_id': quantity }

    for product_id, qty in cart.items():
        product = Product.objects.get(id=product_id)
        if product.stock >= qty:
            product.stock -= qty
            product.save()
        else:
            return HttpResponse("Not enough stock for " + product.name)

    request.session['cart'] = {}  # clear cart
    return HttpResponse("Purchase successful!")

from .models import UserLocation  # import your model

# def cart(request):
#     user_number = request.session.get('number')
#
#     if not user_number:
#         return render(request, 'index.html', {'error_message': 'Please register or login'})
#
#     user_addresses = UserLocation.objects.filter(number=user_number)
#
#     cart = request.session.get('cart', {})  # Sample cart data
#     context = {
#         'cart': cart,
#         'user_addresses': user_addresses
#     }
#     return render(request, 'cart.html', context)

def cart_view(request):
    # your cart view logic here
    return render(request, 'cart.html', context)

def cart(request):
    user_number = request.session.get('number')
    if not user_number:
        return render(request, 'index.html', {'error_message': 'Please register or login'})

    user_addresses = UserLocation.objects.filter(number=user_number)
    cart = request.session.get('cart', {})

    context = {
        'cart': cart,
        'user_addresses': user_addresses
    }
    return render(request, 'cart.html', context)

def add_address(request):
    return render(request, 'add_address.html')

from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from .models import UserLocation

def location_page(request):
    return render(request, 'location_page.html')  # Template you'll create next

@csrf_exempt
def save_location(request):
    if request.method == 'POST':
        data = request.POST
        UserLocation.objects.create(
            name=data.get('name'),
            number=data.get('number'),
            address_line=data.get('address_line'),
            near_by=data.get('near_by'),
            area=data.get('area'),
            district=data.get('district', ''),
            pincode=data.get('pincode', ''),
            latitude=data.get('latitude') or 0,
            longitude=data.get('longitude') or 0
        )
        return redirect('cart')
    return JsonResponse({'error': 'Invalid request'}, status=400)


def select_address(request, address_id):
    try:
        address = UserLocation.objects.get(id=address_id)
        # Save selected address in session
        request.session['user_address'] = {
            'name': address.name,
            'number': address.number,
            'address_line': address.address_line,
            'area': address.area,
            'near_by': address.near_by,
            'pincode': address.pincode,
        }
        return redirect('cart')  # Redirect back to cart page after selection
    except UserLocation.DoesNotExist:
        return redirect('cart')  # If address doesn't exist, redirect to cart page


def payment(request):
    return render(request,'payment.html')